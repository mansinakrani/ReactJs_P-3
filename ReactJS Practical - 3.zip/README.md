# Practical-3 :  To-do list application in React  - part 2: Functional specifications

## Getting Started

Clone this repo and install dependencies with

```bash
  npm install
```

## Starting The Dev Server

To start the server and start hacking, run

```bash
npm start
```

## Demo
[Image](https://github.com/mansinakrani/ReactJs_P-3/blob/reactjs_pr-3/image_Practical-3.png)

## Repo Link
[Practical - 3](https://github.com/mansinakrani/ReactJs_P-3.git)

## PR Link
[PR](https://github.com/mansinakrani/ReactJs_P-3/pull/1#issue-1148878130)

