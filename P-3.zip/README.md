# Practical-3 :  To-do list application in React  - part 2: Functional specifications

## Getting Started

Clone this repo and install dependencies with

```bash
  npm install
```

## Starting The Dev Server

To start the server and start hacking, run

```bash
npm start
```

## Demo
[Image](https://github.com/mansinakrani/ReactJS_pr-3_todo-app/blob/Practical-3_reactJS/image_Practical-3.png)

## Repo Link
[Practical - 3](https://github.com/mansinakrani/ReactJS_pr-3_todo-app/tree/Practical-3_reactJS)