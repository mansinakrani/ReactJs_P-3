import React from "react";
import "./App.css";
import TodoList from "./components/Todo-list";

function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}

export default App;
